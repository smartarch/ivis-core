from setuptools import find_packages, setup

setup(
    name='d_values',
    packages=find_packages(),
    version='1.0',
    description='D-Value estimation with Sentinel-2 NDVI and Weather data.',
    author='Petteri Nevavuori, Mtech Digital Solutions Oy',
    license='',
)
